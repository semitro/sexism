self.__precacheManifest = [
  {
    "revision": "a7d264dc90d7a81e9356",
    "url": "/static/css/main.784a6182.chunk.css"
  },
  {
    "revision": "a7d264dc90d7a81e9356",
    "url": "/static/js/main.8e316465.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "419442c0f271e14b9ed9",
    "url": "/static/css/2.a5a02a8d.chunk.css"
  },
  {
    "revision": "419442c0f271e14b9ed9",
    "url": "/static/js/2.de583c34.chunk.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  },
  {
    "revision": "6adbd65d5e69df9c8fd53b887a3a072d",
    "url": "/index.html"
  }
];